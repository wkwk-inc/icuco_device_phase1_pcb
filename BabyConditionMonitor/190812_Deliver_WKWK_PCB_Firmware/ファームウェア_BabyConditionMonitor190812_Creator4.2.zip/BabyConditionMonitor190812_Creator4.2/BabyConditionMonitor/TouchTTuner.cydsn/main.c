/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

void StackEventHandler( uint32 eventCode, void *eventParam );

/* define the test register to switch the PA/LNA hardware control pins */
#define CYREG_SRSS_TST_DDFT_CTRL 0x40030008

int main (void)
{
__enable_irq(); /* Enable global interrupts. */
EZI2C_Start(); /* Start EZI2C Component */
/*
* Set up communication and initialize data buffer to CapSense data structure
* to use Tuner application
*/
EZI2C_EzI2CSetBuffer1(sizeof(CapSense_dsRam),
sizeof(CapSense_dsRam),
(uint8_t *)&(CapSense_dsRam));
CapSense_Start(); /* Initialize Component */
CapSense_ScanAllWidgets(); /* Scan all widgets */
for(;;)
{
/* Do this only when a scan is done */
if(CapSense_NOT_BUSY == CapSense_IsBusy())
{
CapSense_ProcessAllWidgets(); /* Process all widgets */
CapSense_RunTuner(); /* To sync with Tuner application */
if (CapSense_IsAnyWidgetActive()) /* Scan result verification */
{
/* add custom tasks to execute when touch detected */
}
CapSense_ScanAllWidgets(); /* Start next scan */
}
}
}
