/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "misc.h"
#include "PowerManage.h"
#include <stdlib.h>

/*******************************************************************************
* Function Name: InitializeSystem
********************************************************************************
* Summary:
*        Start the components in the projects.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
extern CY_ISR_PROTO(Wdt_Callback);
void InitializeSystem(void)
{
    uint8 uniqueID[8] = {0},i;
    char string[20] = "wk-ic-01-";
    char stringTemp[10];
	/* Enable Global Interrupt Mask */
	CyGlobalIntEnable;		
	/* Start BLE stack and register the event callback function. This function
	* will be called by BLE stack whenever an activity for application happens.
	* This function recieves various events from BLE stack and its corresponsing 
	* data */
    generateFFTFreq();
    CyGetUniqueId((uint32*)uniqueID);
    for(i=0;i<8;i++)
    {
        itoa(uniqueID[i],stringTemp,16);
        strcat(string,stringTemp);
    }
    CyBle_GapSetLocalName(string);
    CySysClkWcoStart();
    isr_WDT_StartEx(Wdt_Callback);
    /* Set the divider for ECO, ECO will be used as source when IMO is switched off to save power */
    CySysClkWriteEcoDiv(CY_SYS_CLK_ECO_DIV8);
    //CyBle_Start(GeneralEventHandler);

    Pin_PA_CSD_Write(LOW);
    Pin_PA_CPS_Write(LOW);
    
    Control_Reg_Buzzer_Write(1);
    PWM_Buzzer_Start();
    CyDelay(100);
    Control_Reg_Buzzer_Write(0);
    PWM_Buzzer_Stop();
    
    initializeAFE();
    CyBle_Start(GeneralEventHandler);
    BLEPacketUpdate(); 
    CyBle_ProcessEvents();   
    CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
    CyBle_GappStopAdvertisement();
    stopAFE();
    CyBle_Stop();
    Pin_PA_CSD_Write(LOW);
    Pin_PA_CPS_Write(LOW);
    sleepAccel();

    
}
/*******************************************************************************
* Function Name: main
********************************************************************************
* Summary:
*        System entry point for starting components and application processing
*
* Parameters:
*  void
*
* Return:
*  int
*
*******************************************************************************/
extern PowerMode_t applicationPower;
extern uint8 bufferReadingFlag; /* declared in BLEprocess.c*/
extern uint8 mode;
extern uint8 speedFlag;
extern uint8 bleStackOn;
extern uint8 packetUpdateFlag;
extern uint8 batteryLevel;
#define SLEEPENABLE

extern uint8 buzzerStatus;
extern uint8 buzzerBleControlCounter;
extern uint8 chargeNeed;
extern uint16 fftCounter;
extern uint16 accelFFTCounter;

int main()
{    
    /* Start the components */
	InitializeSystem();   
    mode = MODE_NONE;
    applicationPower = DEEPSLEEP;
    for(;;)
    {
        if(applicationPower == ACTIVE)
        {
            /* Super Speed Mode for Debug purpose*/
            if(speedFlag ==  TRUE)
            {
                BLEPacketUpdate(); 
                applicationPower = DEEPSLEEP;
            }
            else
            {
                /* Normal application Mode */
                if(packetUpdateFlag == TRUE)
                {       
                    /* only while BLE communication */
                    if(mode == MODE_ACTIVE)
                    {
                        BLEPacketUpdate(); 
                    }
                    /* check battery voltage */       
                    checkBatteryVoltage();
                    /* udpate charge status */
                    updateChargerLED();     
                    /* if battery voltage is low */
                    if(!chargeNeed)
                    {
                         /* if battery need charge do not try to see touch sensor */
                        touchStatusUpdate();  
                    }
                    /* clear packet update flag */
                    packetUpdateFlag = FALSE;
                    
                    /* set power mode to deep sleep */
                    applicationPower = DEEPSLEEP;
                    
                    /* control LED+Buzzer from Host throguh BLE */
                    ledControl();       /* control LED from BLE host */
                    buzzerControl();    /* do not place this before ledControl */         
                }
                else
                {
                    /* if buzzer is not enabled then set to DEEPSLEEP*/
                    if( buzzerBleControlCounter == 0)
                    {
                        applicationPower = DEEPSLEEP;
                    }
                    
                    if(fftCounter >= 256)
                    {
                        processFFTHRCaluculation();
                        fftCounter = 0;
                    }
                    else if(accelFFTCounter >= 256)    /* won't execute at same ACTIVE phase */
                    {
                        processFFTAccelCalculation();
                        accelFFTCounter = 0;
                    }

                }
            }   
        }
        
        #ifdef SLEEPENABLE
        ManageApplicationPower();   
        ManageSystemPower();
        if(mode == MODE_ACTIVE)
        {
            CyBle_ProcessEvents();   
            CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
        }

        #else
        applicationPower = ACTIVE;
        CyBle_ProcessEvents();   
        #endif
    }
}

/* [] END OF FILE */
