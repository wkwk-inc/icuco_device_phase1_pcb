#if !defined(POWERMANAGE_H)
#define POWERMANAGE_H
    
#include <project.h>
    
void ManageSystemPower();
void ManageApplicationPower();

typedef enum PowerMode_t {
WAKEUP_SLEEP,
WAKEUP_DEEPSLEEP,
ACTIVE,
SLEEP,
DEEPSLEEP
} PowerMode_t;
    
#endif /* POWERMANAGE_H */    
    
/* [] END OF FILE */
