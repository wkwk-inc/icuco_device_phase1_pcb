#include "project.h"
#include "misc.h"
#include "PowerManage.h"


/******************************************************************************
Global variables declaration
*******************************************************************************/
CYBLE_API_RESULT_T apiResult;
PowerMode_t applicationPower;
extern uint8 mode;
/*******************************************************************************
* Function Name: ManageSystemPower()
********************************************************************************
*
* Summary:
*   This function puts the system in appropriate low power modes based on the 
*   state of BLESS and application power state.
*
* Parameters:
*  none
*
********************************************************************************/

#define CYREG_SRSS_TST_DDFT_CTRL 0x40030008
void lowpowerPA()
{
    if(mode == MODE_ACTIVE)
    {
        Pin_PA_CSD_Write(LOW);
        Pin_PA_CPS_Write(LOW);
    }
}
void enablePA()
{
    if(mode == MODE_ACTIVE)
    {
        Pin_PA_CSD_Write(HIGH);
        Pin_PA_CPS_Write(HIGH);
    }
}
void ManageSystemPower()
{
    /* Variable declarations */
    CYBLE_BLESS_STATE_T blePower;
    uint8 interruptStatus ;
    
   /* Disable global interrupts to avoid any other tasks from interrupting this section of code*/
    interruptStatus  = CyEnterCriticalSection();
    
    if(mode == MODE_ACTIVE)
    {
        /* Get current state of BLE sub system to check if it has successfully entered deep sleep state */
        blePower = CyBle_GetBleSsState();
    }
    else
    {
        blePower = CYBLE_BLESS_STATE_DEEPSLEEP;
    }

    /* System can enter DeepSleep only when BLESS and rest of the application are in DeepSleep or equivalent
     * power modes */
    if((blePower == CYBLE_BLESS_STATE_DEEPSLEEP || blePower == CYBLE_BLESS_STATE_ECO_ON) && 
        applicationPower == DEEPSLEEP)
    {
        applicationPower = WAKEUP_DEEPSLEEP;
        lowpowerPA();
        CySysPmDeepSleep();
        enablePA();
    }
    else if((blePower != CYBLE_BLESS_STATE_EVENT_CLOSE))
    {
        if(applicationPower == DEEPSLEEP)
        {
            applicationPower = WAKEUP_DEEPSLEEP;
            ///lowpowerPA();
            /* change HF clock source from IMO to ECO, as IMO is not required and can be stopped to save power */
            CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_ECO); 
            /* stop IMO for reducing power consumption */
            CySysClkImoStop();            
            /* put the CPU to sleep */
            //lowpowerPA();
            CySysPmSleep();     
            //enablePA();
            /* starts execution after waking up, start IMO */
            CySysClkImoStart();
            /* change HF clock source back to IMO */
            CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_IMO);
            //enablePA();
        }
        else if(applicationPower == SLEEP )
        {
            /* If the application requires IMO for its operation, we should not switch the HFCLK source */
            applicationPower = WAKEUP_SLEEP;              
            CySysPmSleep();
        }
    }
    
    /* Enable interrupts */
    CyExitCriticalSection(interruptStatus );

}




/*******************************************************************************
* Function Name: ManageApplicationPower()
********************************************************************************
*
* Summary:
*   This function puts the application componnents in appropriate low power modes 
*   based on the state of the components.
*
* Parameters:
*  none
*
********************************************************************************/

void ManageApplicationPower()
{
    switch(applicationPower)
    {
        case ACTIVE: // dont need to do anything
        break;
        
        case WAKEUP_SLEEP: // do whatever wakeup needs to be done - probably never do anything          
            //enablePA();
            applicationPower = ACTIVE;
        break;
        
        case WAKEUP_DEEPSLEEP: // do whatever wakeup needs to be done.       
            //enablePA();
            applicationPower = ACTIVE;
        break;
        
        case SLEEP: 
            /** Add code to place the application components to sleep here  */
            //lowpowerPA();
        break;
        
        case DEEPSLEEP:
            /** Add code to place the application components to deep sleep here  */     
            //lowpowerPA();
        break;
    }
}


/* [] END OF FILE */
