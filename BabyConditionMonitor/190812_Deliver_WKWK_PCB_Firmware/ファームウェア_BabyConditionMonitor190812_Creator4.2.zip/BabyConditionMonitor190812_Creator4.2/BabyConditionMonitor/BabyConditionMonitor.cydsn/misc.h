#if !defined(MISC_H)
#define MISC_H
#include <project.h>
#include "BLEProcess.h"
	
/********************************** Macors ******************************************/
#define BUFFER_SIZE         (14)
#define TRANSFER_ERROR      (1)
#define TRANSFER_CMPLT      (0)
#define I2CADDRESS          (0x68)
#define TEMPSENSOR_ADDRESS  (0x48)  /* Right justified (90h is 8bit)*/
#define ACCELGYRO_ADDRESS   (0x68) 
#define ADPD1080_ADDRESS    (0x64)
    
    
/* Macros for LED control */
#define LED_RED_ON          Pin_LED_RED_Write(LOW)
#define LED_RED_OFF         Pin_LED_RED_Write(HIGH)
#define LED_BLUE_ON         Pin_LED_BLUE_Write(LOW)
#define LED_BLUE_TOGGLE     Pin_LED_BLUE_Write(!Pin_LED_BLUE_Read())
#define LED_BLUE_OFF        Pin_LED_BLUE_Write(HIGH)
#define LED_GREEN_ON        Pin_LED_GREEN_Write(LOW)
#define LED_GREEN_OFF       Pin_LED_GREEN_Write(HIGH)
    
#define RAMBLEPACKETLENGTH  (1) //(128)
#define RAMBUFFERLENGTH     (1) //(8)     /* default 8 */
#define ROWBASE (0x2E9)
    
#define MODE_PREPARE_TEMP   (1)
#define MODE_1MIN           (2)
#define MODE_NONE           (3)
#define MODE_ACTIVE           (4)
    
#define ACCEL_BUFFER_SIZE   (14)
#define ACCEL_GYRO_SENSOR_READ       (0x3B)

    
#define BLE_NOTIFICATION_BUFFER_SIZE    (20)
#define BLE_ALEARTNOTIFICATION_BUFFER_SIZE  (10)
    
    
/* Array definition for notification Aleart */
#define TOUCHDETECT         (0)
    
/* Macros for AFE */
#define AFECONTROL0         (0x00)
#define LED2STC             (0x01)
#define LED2ENDC            (0x02)
#define LED2LEDSTC          (0x03)
#define LED2LEDENDC         (0x04)
#define ALED2STC            (0x05)
#define ALED2ENDC           (0x06)
#define LED1STC             (0x07)
#define LED1ENDC            (0x08)
#define LED1LEDSTC          (0x09)
#define LED1LEDENDC         (0x0A)
#define ALED1STC            (0x0B)
#define ALED1ENDC           (0x0C)
#define LED2CONVST          (0x0D)
#define LED2CONVEND         (0x0E)
#define ALED2CONVST         (0x0F)
#define ALED2CONVEND        (0x10)
#define LED1CONVST          (0x11)
#define LED1CONVEND         (0x12)
#define ALED1CONVST         (0x13)
#define ALED1CONVEND        (0x14)
#define ADCRSTSTCT0         (0x15)
#define ADCRSTENDCT0        (0x16)
#define ADCRSTSTCT1         (0x17)
#define ADCRSTENDCT1        (0x18)
#define ADCRSTSTCT2         (0x19)
#define ADCRSTENDCT2        (0x1A)
#define ADCRSTSTCT3         (0x1B)
#define ADCRSTENDCT3        (0x1C)    
#define PRPCOUNT            (0x1D)
#define AFECONTROL1         (0x1E)   

    
#define SUBLED2VAL          (0x2E)
#define SUBLED1VAL          (0x2F)
    
/* number of FFT */
#define FFTNUMBER   (256)
    
/* General Macros*/
#define HIGH    (1)
#define LOW     (0)

#define TRUE    (1)
#define FALSE   (0)

#define WDT_INTERVAL_VALIUE     (2)             /* set inter WDT interval value here [sec] */
#define INTERVAL_TIME_SEC       (60)
#define SEC_COUNTER_MAX         (INTERVAL_TIME_SEC/WDT_INTERVAL_VALIUE)  /* put desired sec value */   
#define INITIAL_SEC_COUTER      (SEC_COUNTER_MAX -1) 
#define SENSOR_MODE_NORMAL      (1)
#define SENSOR_MODE_STOP        (2)

/******************************************************************************************/

/******************************* Function Declaration *************************************/
void BLEPacketUpdate(void);
void getTemperature(void);
void prepareTemperature(void);
void backUpBuffer(uint8);
void Wdt_Callback(void) ;
void switchProcess(void);
void blinkRedLED(void);
void mode_prepare();
void mode_1min();
uint32 getAccel(void);
uint32 getColor(void);
uint32 initializeColor(void);
void updateNotificationPacket(void);
void i2cWriteByte(uint8,uint8);
void SPI_Write_Data(uint8,uint16);
void setupAFE();
void AFE44xx_Default_Reg_Init(void);
void SPI_Write_3BYTESData(uint8, uint8,uint8,uint8);
void initializeAFE(void);
void readAFE(void);
void checkSpeedUp(void);
void startBreathLED(void);
void stopBreathLED(void);
void touchStatusUpdate(void);
void longTouchDetect(void);
void updateChargerLED(void);
void stopAFE(void);
void sleepAccel(void);
void buzzerON(void);
void buzzerOFF(void);
void buzzerControl(void);
void ledControl(void);
void powerControl(void);
void processFFTHRCaluculation(void);
void processFFTAccelCalculation(void);
void generateFFTFreq(void);
void BLEParametersUpdateRquest(void);
/********************************************************************************************/
struct  blePacket{
            uint16 strain;
            uint8 temperature_msb;
            uint8 temperature_lsb;
        };
struct blePacket packet[RAMBLEPACKETLENGTH];    
uint16 checkBatteryVoltage();
#endif /* MISC_H */
/* [] END OF FILE */
