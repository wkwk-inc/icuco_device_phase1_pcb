/********************************************************************************
Copyright 2014-15, Cypress Semiconductor Corporation.  All rights reserved.
You may use this file only in accordance with the license, terms, conditions,
disclaimers, and limitations in the end user license agreement accompanying
the software package with which this file was provided.
*******************************************************************************/
#if !defined (BLEPROCESS_H)
#define BLEPROCESS_H
#include <project.h>

/******************************* Function Declaration *************************************/
void GeneralEventHandler(uint32 , void*);
/********************************************************************************************/
#define BLE_BUFFER_COUNTER_MSB      (0)
#define BLE_BUFFER_COUNTER_LSB      (1)
#define BLE_BUFFER_STRAIN_MSB       (2)
#define BLE_BUFFER_STRAIN_LSB       (3)
#define BLE_BUFFER_TEMPERATURE_MSB  (4)
#define BLE_BUFFER_TEMPERATURE_LSB  (5)
#define BLE_BUFFER_BATTERY          (6)

/* definition for Custom Debug char */
#define CUSTOMDEBUG_SPEEDUP (0)
#define CUSTOMDEBUG_LED     (1)
#define CUSTOMDEBUG_BUZZER  (2)

/* definition for Custom Order char */
#define CUSTOMORDER_LED     (0)
#define CUSTOMORDER_BUZZER  (1)
#endif
/* [] END OF FILE */
