/******************************************************************************
* Project Name		: AN91162
* File Name			: BLEProcess.c
* Version 			: 1.0
* Owner             : AFUR
*/
/*******************************************************************************
* Contains function definitions for Event callback handler function for BLE 
* events as well as updating RGB characteristic GATT DB
*******************************************************************************/
#include "misc.h"
#include "PowerManage.h"
#include "stdlib.h"

/*******************************************************************************
* Function Name: GeneralEventHandler
********************************************************************************
* Summary:
*        General callback event handler function for BLE component through which
* application recieves various BLE events.
*
* Parameters:
*  event:		event type. See "CYBLE_EVENT_T" structure in BLE_Stack.h
*  eventParam: 	parameter associated with the event
*
* Return:
*  void
*
*******************************************************************************/
extern struct blePacket packet[];
extern uint16 bleBufferCounter;
extern CYBLE_API_RESULT_T apiResult;
extern uint8 BLEParametersRquestUpdatedFlag;
#define ADV_RAND_DISABLE_MASK      0x100
#define CAPACITOR_TRIM_VALUE       0x00004355
extern uint8 batteryLevel;
/* define the test register to switch the PA/LNA hardware control pins */
#define CYREG_SRSS_TST_DDFT_CTRL 0x40030008
extern uint8 speedFlag;
uint8 bufferReadingFlag=FALSE;
uint8 buzzerBleControlCounter = 0;
uint8 ledBleControlCounter = 0;
extern uint8 notifyBuffer[];
__inline void GeneralEventHandler(uint32 event, void * eventParam)
{
	/* Structure to store data written by Client */	
	CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    //uint8  buffer[7] = {0};
    uint32 register_value;
    CYBLE_BLESS_CLK_CFG_PARAMS_T clockConfig;
    
    (void)eventParam;
    /* 'dataHandle' stores control data parameters */
	//CYBLE_GATT_HANDLE_VALUE_PAIR_T		dataHandle;
	switch(event)
    {
		case CYBLE_EVT_STACK_ON:
//            Pin_PA_CSD_Write(HIGH);
//            Pin_PA_CPS_Write(HIGH);
            
            CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLESS_RF_CONFIG), 0x0331);
            CY_SET_XTND_REG32((void CYFAR *)(CYREG_SRSS_TST_DDFT_CTRL), 0x80000302);
			/* load capacitors on the ECO should be tuned and the tuned value
            ** must be set in the CY_SYS_XTAL_BLERD_BB_XO_CAPTRIM_REG  */
            CY_SYS_XTAL_BLERD_BB_XO_CAPTRIM_REG = CAPACITOR_TRIM_VALUE;    
        
            /* Get the configured clock parameters for BLE sub-system */
            CyBle_GetBleClockCfgParam(&clockConfig);    
            
            /* Update the sleep clock inaccuracy PPM based on WCO crystal used */
            /* If you see frequent link disconnection, tune your WCO or update the sleep clock accuracy here */
            clockConfig.bleLlSca =   CYBLE_LL_SCA_000_TO_020_PPM;
            
            /* set the clock configuration parameter of BLE sub-system with updated values*/
            CyBle_SetBleClockCfgParam(&clockConfig);
            
            /* Disable randomization of advertisment interval in CYREG_BLE_BLELL_ADV_CONFIG register 
            ** This is for current measurement ONLY to ensure the BLE component uses fixed advertisement **
            ** Interval. This code should not be used in production builds */
    
            register_value = CY_GET_XTND_REG32(CYREG_BLE_BLELL_ADV_CONFIG);
            register_value |= ADV_RAND_DISABLE_MASK;
            CY_SET_XTND_REG32(CYREG_BLE_BLELL_ADV_CONFIG, register_value);
            
            /* Put the device into discoverable mode so that a central device can connect to it */
            apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            
            break;
				
		case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
			/* This event is generated at GAP disconnection. */
			/* Restart advertisement */
            /* Put the device into discoverable mode so that a central device can connect to it */
            apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            speedFlag=FALSE;
            BLEParametersRquestUpdatedFlag = FALSE;
		break;
            
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            BLEParametersUpdateRquest();
        break;

        case CYBLE_EVT_GATTS_WRITE_REQ: 
			/* This event is generated when the connected Central device sends a
			* Write request. The parameter contains the data written */
			
			/* Extract the Write data sent by Client */
            wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
			
			/* If the attribute handle of the characteristic written to 
			* is equal to that of Sensor characteristic */           
            
			/* Send the response to the write request. */
			CyBle_GattsWriteRsp(cyBle_connHandle);
            
            if(CYBLE_WKWK_CUSTOMDEBUG_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
                if(wrReqParam->handleValPair.value.val[CUSTOMDEBUG_SPEEDUP])
                {
                    speedFlag=TRUE;
                }
                else
                {
                    speedFlag=FALSE;
                }
                
                if(wrReqParam->handleValPair.value.val[CUSTOMDEBUG_LED])
                {
                    ledBleControlCounter = 1;
                }
                else
                {
                    ledBleControlCounter = 0;
                }
                
                 if(wrReqParam->handleValPair.value.val[CUSTOMDEBUG_BUZZER])
                {
                    buzzerBleControlCounter=1;
                }
                else
                {
                    buzzerBleControlCounter=0;
                }
                
            }
            

            if(CYBLE_WKWK_CUSTOMORDER_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
                ledBleControlCounter=wrReqParam->handleValPair.value.val[CUSTOMORDER_LED];
                buzzerBleControlCounter=wrReqParam->handleValPair.value.val[CUSTOMORDER_BUZZER]; 
                
                notifyBuffer[16] = CyBle_GetRssi();

            }
            
			break;
        default:
       	    break;
    }   	
}


/* [] END OF FILE */
