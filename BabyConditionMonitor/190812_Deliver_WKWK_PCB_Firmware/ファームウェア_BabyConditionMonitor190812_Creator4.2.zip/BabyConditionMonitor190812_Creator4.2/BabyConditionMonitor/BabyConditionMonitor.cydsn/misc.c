#include "misc.h"
#include "BLEProcess.h"
#include "PowerManage.h"
#include "ZeroFFT.h"

uint8 flagWake = FALSE;
uint8 packetUpdateFlag=0;
uint8 speedFlag=FALSE;
uint16 adcStrainResult;
uint16 bleBufferCounter = 0;
uint8 secCounter = INITIAL_SEC_COUTER;
/* check battery amount then return to call source */
uint8 batteryLevel = 100;
uint8 chargeNeed = FALSE;
uint8 mode=MODE_NONE;
uint16 checkBatteryVoltage()
{
    uint16 batteryResult;
    Opamp_ADC_BUF_Start();
    ADC_SetChanMask(0x01);
    ADC_Start();
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    batteryResult =  ADC_CountsTo_mVolts(0, ADC_GetResult16(0)) * 2;
    ADC_StopConvert();
    ADC_Stop();
       Opamp_ADC_BUF_Stop();
    if(batteryResult < 3200)
    {
        chargeNeed = TRUE;
        if(mode == MODE_ACTIVE)
        {
            /* turn off BLE if active */
            powerControl();
        }
    }
    else
    {
        chargeNeed = FALSE;
    }
    batteryLevel = (batteryResult - 3200)*10/95;
    if(batteryLevel > 100)
    {
        batteryLevel = 100;
    }
    
    return batteryResult;
}

/* simply write two byte of datas to slave */
void i2cWrite(uint8 slaveAddress,uint8 cmd, uint8 data)
{
    uint8 i2c_timeout = 100;
    I2C_I2CMasterSendStart(slaveAddress,I2C_I2C_WRITE_XFER_MODE,i2c_timeout);
    I2C_I2CMasterWriteByte(cmd,i2c_timeout);
    I2C_I2CMasterWriteByte(data,i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    I2C_I2CMasterClearStatus();
}

/* simply write three byte of datas to slave */
void i2cWrite3(uint8 slaveAddress,uint8 cmd, uint8 data1,uint8 data2)
{
    uint8 i2c_timeout = 100;
    I2C_I2CMasterSendStart(slaveAddress,I2C_I2C_WRITE_XFER_MODE,i2c_timeout);
    I2C_I2CMasterWriteByte(cmd,i2c_timeout);
    I2C_I2CMasterWriteByte(data1,i2c_timeout);
    I2C_I2CMasterWriteByte(data2,i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    I2C_I2CMasterClearStatus();
}

/*Specific read method for temperature sensor */
void i2cRepeatStartRead(uint8 slaveAddress,uint8 cmd, uint8 *RXbuffer, uint8 readBytes)
{
    uint8 i;
    uint8 i2c_timeout = 100;
    I2C_I2CMasterSendStart(slaveAddress,I2C_I2C_WRITE_XFER_MODE,i2c_timeout);
    I2C_I2CMasterWriteByte(cmd,i2c_timeout);
    I2C_I2CMasterSendRestart(slaveAddress, I2C_I2C_READ_XFER_MODE,i2c_timeout);
    for(i = 0; i < (readBytes - 1);i++)
    {
         I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&RXbuffer[i],i2c_timeout);
    }
    I2C_I2CMasterReadByte(I2C_I2C_NAK_DATA,&RXbuffer[i],i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    I2C_I2CMasterClearStatus();
}

void i2cWriteByte(uint8 slaveAddress,uint8 cmd)
{
    
    uint8 i2c_timeout = 100;
    I2C_I2CMasterSendStart(slaveAddress,I2C_I2C_WRITE_XFER_MODE,i2c_timeout);
    I2C_I2CMasterWriteByte(cmd,i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    I2C_I2CMasterClearStatus();
}

/* convert temperatrure from 2 compliment digital data */
uint8 temperatureConverter(uint8 value)
{
    float tempResult;
    uint8 result;
    tempResult = 1.0/256 * (value & 0x01) + 1.0/128 * ((value>>1) & 0x01) + 1.0/64 * ((value>>2) & 0x01)
            + 1.0/32 * ((value>>3) & 0x01) + 1.0/16 * ((value>>4) & 0x01) + 1.0/8 * ((value>>5) & 0x01) 
            + 1.0/4 * ((value>>6) & 0x01) + 1.0/2 * ((value>>7) & 0x01);
    result = tempResult * 100;        
    return result;
}

#define BLINKMAX    (8)
void updateChargerLED(void)
{
    static uint8 blinkCounter=0;
    blinkCounter++;
    if(blinkCounter==BLINKMAX)
    {
        blinkCounter = 0;
    }
    
    if(batteryLevel==100)//if(!Pin_CHARGER_STAT2_Read())
    {
        if((!Pin_CHARGER_STAT1_Read()) || (!Pin_CHARGER_STAT2_Read()))
        {
            LED_RED_ON;
        }
        else
        {
            LED_RED_OFF;
        }
    }
    else
    {
        LED_RED_OFF;
        if(!Pin_CHARGER_STAT1_Read())
        {
            if(blinkCounter > (BLINKMAX/2))
            {
                LED_RED_ON;
            }
            else
            {
                LED_RED_OFF;
            }
        }
    }
    
}

extern uint8 sensorMode;
uint16 writeROW;

#define CAPSENSE
#define COLOR
#define ACCEL
/* Update Strain sensor value andTemperature Sensor value */
extern uint8 bufferReadingFlag;
uint8 colorSesorInitrequireFlag = TRUE,colorSensorReadyFlag = FALSE;
uint8 notifyBuffer[BLE_NOTIFICATION_BUFFER_SIZE];
uint8 notifyAleartBuffer[BLE_ALEARTNOTIFICATION_BUFFER_SIZE];
uint8 temperatureBufferConverted[2],TemperatureBuffer[2] = {0};
uint16 rawCount;
uint32 TouchResult = 0;
void BLEPacketUpdate()
{
    prepareTemperature();
    /* start to get temperature data */
    getAccel();
    getTemperature();
    readAFE();
   
    updateNotificationPacket();
//    Pin_PA_CSD_Write(HIGH);
//    Pin_PA_CPS_Write(HIGH);
    
    /* Get a handle for the notification characteristic */
    CYBLE_GATTS_HANDLE_VALUE_NTF_T tempHandle;
    /* Take the characteristic */
    tempHandle.attrHandle = CYBLE_WKWK_CUSTOMCONTROL_CHAR_HANDLE;
    /* Update the value and specify the length */
    tempHandle.value.val = notifyBuffer;
    tempHandle.value.len = BLE_NOTIFICATION_BUFFER_SIZE;
    
    /* send notification */
    CyBle_GattsNotification(cyBle_connHandle,&tempHandle);

}

void bleAleartNotification(void)
{

    /* Get a handle for the notification characteristic */
    CYBLE_GATTS_HANDLE_VALUE_NTF_T tempHandle;
    /* Take the characteristic */
    tempHandle.attrHandle = CYBLE_WKWK_CUSTOMALEARTNOTIFICATION_CHAR_HANDLE;
    /* Update the value and specify the length */
    tempHandle.value.val = notifyAleartBuffer;
    tempHandle.value.len = BLE_NOTIFICATION_BUFFER_SIZE;
    
    /* send notification */
    CyBle_GattsNotification(cyBle_connHandle,&tempHandle);

}

#define TOUCHDETECTEDTH     (3620)
uint8 capsenseStartFlag = FALSE;
uint8 firstActive = TRUE;
uint8 firstNone = FALSE;
void touchStatusUpdate()
{
    /* Scan widget configured by CSDSetupWidgetExt API */
    if(capsenseStartFlag == FALSE)
    {
        CapSense_Start();
        CapSense_CSDSetupWidgetExt(CapSense_BUTTON0_WDGT_ID, CapSense_BUTTON0_SNS0_ID);
        capsenseStartFlag = TRUE;
    }
    else
    {
        CapSense_Wakeup();
    }
    
    CapSense_CSDScanExt();
    while(CapSense_NOT_BUSY != CapSense_IsBusy()){};

    rawCount = CapSense_dsRam.snsList.button0[CapSense_BUTTON0_SNS0_ID].raw[0];
    if(rawCount > TOUCHDETECTEDTH)
    {
        if(TouchResult == FALSE)
        {
            TouchResult = TRUE;
            notifyAleartBuffer[TOUCHDETECT] = 1;
            if(mode == MODE_ACTIVE)
            {
                bleAleartNotification();
                notifyAleartBuffer[TOUCHDETECT] = 0;
            }
        }
        
        if(mode == MODE_ACTIVE)
        {
            if(firstActive)
            {
                LED_BLUE_ON;
                LED_GREEN_OFF;
                firstNone = TRUE;
            }
            else
            {
                LED_BLUE_TOGGLE;
            }
        }
        
        if(mode == MODE_NONE)
        {
            if(firstNone)
            {
                LED_BLUE_OFF;
            }
            else
            {
                LED_GREEN_ON;
            }
        }
    }
    else
    {
        TouchResult = FALSE;

        if(mode == MODE_ACTIVE)
        {
            LED_BLUE_ON;
            firstActive = FALSE;
        }
        
        if(mode == MODE_NONE)
        {
            LED_BLUE_OFF;
            LED_GREEN_OFF;
            firstActive = TRUE;
            firstNone = FALSE;

        }
    }
    
    CapSense_Sleep();
    
    longTouchDetect();
}

uint8 buzzerStatus=FALSE;
void buzzerON(void)
{
    Control_Reg_Buzzer_Write(1);
    PWM_Buzzer_Start();
    buzzerStatus = TRUE;
}

void buzzerOFF(void)
{
    Control_Reg_Buzzer_Write(0);
    PWM_Buzzer_Stop();
    buzzerStatus = FALSE;
}


uint8 buzzerCounter =0;
extern uint8 buzzerBleControlCounter;
extern PowerMode_t applicationPower;
void buzzerControl(void)
{
    if(buzzerBleControlCounter)
    {
        if(buzzerStatus == FALSE)
        {
            buzzerON();
        }
        
        buzzerCounter++;
        /* determin stop buzzer or not every 1sec(950ms) */
        if(buzzerCounter == 6)
        {
            buzzerCounter = 0;
            buzzerBleControlCounter -= 1;
            if(buzzerBleControlCounter == 0)
            {
                buzzerOFF();
            }
        }
        applicationPower = ACTIVE;
    }
}

uint8 ledCounter =0;
extern uint8 ledBleControlCounter;
void ledControl(void)
{
    if(ledBleControlCounter)
    {

        LED_GREEN_ON;

        ledCounter++;
        /* determin stop buzzer or not every 1sec(950ms) */
        if(ledCounter == 6)
        {
            ledCounter = 0;
            ledBleControlCounter -= 1;
            if(ledBleControlCounter == 0)
            {
                LED_GREEN_OFF;
            }
        }
        applicationPower = DEEPSLEEP;
    }
}



void powerControl()
{
    if(mode == MODE_NONE)
    {
        mode = MODE_ACTIVE;
        Pin_PA_CSD_Write(HIGH);
        Pin_PA_CPS_Write(HIGH);
        initializeAFE();
        CyBle_Start(GeneralEventHandler);
        CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST); 
    }
    else
    {
        mode = MODE_NONE;
        CyBle_ProcessEvents();   
        CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
        CyBle_GappStopAdvertisement();
        CyBle_Stop();
        stopAFE();
        Pin_PA_CSD_Write(LOW);
        Pin_PA_CPS_Write(LOW);
        sleepAccel();
    }
}

#define LONGTOUCHTHON   (7)    /* 450ms x 7 = 3sec*/
#define LONGTOUCHTHOFF  (33)    /* 150ms x 33 = 4.95sec*/
uint8 longTouchCounter = 0;
void longTouchDetect()
{
    if(TouchResult==TRUE)
    {
        longTouchCounter++;
        if(mode == MODE_NONE)
        {
            if(longTouchCounter > LONGTOUCHTHON)
            {
                powerControl();
                longTouchCounter = 0;
            }
        }
        else
        {
            if(longTouchCounter > LONGTOUCHTHOFF)
            {
                powerControl();
                longTouchCounter = 0;
            }
        }
    } 
    else
    {
        longTouchCounter = 0;
    }
}

/* this function is call back for watch dog timer */
/* every accurate 150msec will call this function */

uint8 bleAccessCounter = 0; /* while reading from host increase this counter for timeout*/
uint8 oldBleBufferCounter;

CY_ISR_PROTO(Wdt_Callback);
CY_ISR(Wdt_Callback)
{
    CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER0_INT);
    secCounter++;
    if(!chargeNeed)
    {
        if(mode == MODE_ACTIVE)
        {
            packetUpdateFlag= TRUE;/* check every 150msec when power is off */
            secCounter=0;
        }
        else if(secCounter > 2) /* check every 450msec when power is off */
        {
            packetUpdateFlag= TRUE;
            secCounter=0;
        }
    }
    else if(secCounter == 33)   /* check every 5 sec when battery need charge */
    {
        packetUpdateFlag= TRUE;
        secCounter=0;
    }
    isr_WDT_ClearPending();
}


/* Blink RED LED 3 times */
void blinkRedLED()
{
    uint8 i;
    for(i=0;i<3;i++)
    {
        LED_RED_ON;
        CyDelay(300);
        LED_RED_OFF;
        CyDelay(300);
    }
}

CYBLE_GAP_BD_ADDR_T clearAllDevices = {{0,0,0,0,0,0},0};
/* This function handle switch pressed reaction */
uint8 sensorMode = SENSOR_MODE_NORMAL;
void switchProcess()
{
    //uint8 switchStatus;
    //static uint8 switchHoldCounter = 0;
}
uint8 accelgyrobuffer[ACCEL_BUFFER_SIZE] = {0};
uint16 wakeCounter = 0;
#define WAKECOUNTTHRESHHOLD  (67)
#define SLEEPCOUNTTHRESHHOLD  (400)
#define WAKEACCELTHRESHHOLD  (0xD000)
void determinWake(void)
{
    uint16 accelData = 0;
    accelData = (((uint16)accelgyrobuffer[2]) << 8) +  accelgyrobuffer[3];
    
    if(!flagWake)
    {
        if(accelData > WAKEACCELTHRESHHOLD)
        {
            wakeCounter++;
            if(wakeCounter > WAKECOUNTTHRESHHOLD)
            {
                flagWake = TRUE;
                wakeCounter = 0;
            }
        }
        else
        {
            wakeCounter = 0;
        }
    }
    else
    {
        if(accelData < WAKEACCELTHRESHHOLD)
        {
            wakeCounter++;
            if(wakeCounter > SLEEPCOUNTTHRESHHOLD)
            {
                flagWake = FALSE;
                wakeCounter = 0;
            }
        }
        else
        {
            wakeCounter = 0;
        }
    }

}

union accel_gyro_union{
  struct {
    uint8_t x_accel_h;
    uint8_t x_accel_l;
    uint8_t y_accel_h;
    uint8_t y_accel_l;
    uint8_t z_accel_h;
    uint8_t z_accel_l;
    uint8_t t_h;
    uint8_t t_l;
    uint8_t x_gyro_h;
    uint8_t x_gyro_l;
    uint8_t y_gyro_h;
    uint8_t y_gyro_l;
    uint8_t z_gyro_h;
    uint8_t z_gyro_l;
  }
  reg;
  struct {
    int16_t x_accel;
    int16_t y_accel;
    int16_t z_accel;
    int16_t temperature;
    int16_t x_gyro;
    int16_t y_gyro;
    int16_t z_gyro;
  }
  value;
};


q15_t accelFFTBuffer[FFTNUMBER +1] = {0};
uint16 accelFFTCounter = 0; 
uint32 getAccel(void)
{
    uint8 i2c_timeout = 100,i;
    uint32 tstatus = TRANSFER_ERROR;
    int16 *accelx,*accely,*accelz;
    uint8 convertBuffer[6] = {0};
    I2C_Start();
    /* wake up Accel Gyro Sensor */
    i2cWrite(ACCELGYRO_ADDRESS,0x6B,0x00);
    i2cWrite(ACCELGYRO_ADDRESS,0x6A,0x40);
    i2cWriteByte(ACCELGYRO_ADDRESS,ACCEL_GYRO_SENSOR_READ);
    
    I2C_I2CMasterSendStart(ACCELGYRO_ADDRESS, I2C_I2C_READ_XFER_MODE,i2c_timeout);
   
    for(i = 0; i < ACCEL_BUFFER_SIZE;i++)
    {
       tstatus =  I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&accelgyrobuffer[i],i2c_timeout);
    }
    I2C_I2CMasterSendStop(i2c_timeout);
    I2C_I2CMasterClearStatus();
    I2C_Stop();
    determinWake();
    convertBuffer[0] = accelgyrobuffer[1];
    convertBuffer[1] = accelgyrobuffer[0];
    convertBuffer[2] = accelgyrobuffer[3];
    convertBuffer[3] = accelgyrobuffer[2];
    convertBuffer[4] = accelgyrobuffer[5];
    convertBuffer[5] = accelgyrobuffer[4];
    
    accelx = (int16*)convertBuffer;
    accely = (int16*)(convertBuffer+2);
    accelz = (int16*)(convertBuffer+4);
//    accelFFTBuffer[accelFFTCounter] = ((((((uint16)accelgyrobuffer[0]) << 8)+(uint16)accelgyrobuffer[1]))/6)
//                                    +((((((uint16)accelgyrobuffer[2]) << 8)+(uint16)accelgyrobuffer[3]))/6)
//                                    +((((((uint16)accelgyrobuffer[4]) << 8)+(uint16)accelgyrobuffer[5]))/6);
    accelFFTBuffer[accelFFTCounter] = (*accelx)/3 + (*accely)/3 + (*accelz)/3;
    accelFFTCounter++;
    return tstatus;
}

void sleepAccel()
{
    I2C_Start();
    i2cWrite(ACCELGYRO_ADDRESS,0x6B,0x40);
    I2C_Stop();
}

void prepareTemperature(void)
{
    I2C_Start();
    i2cWrite(TEMPSENSOR_ADDRESS,0x01,0x00);
    i2cWrite(TEMPSENSOR_ADDRESS,0x01,0x81);
    I2C_Stop();
}

void getTemperature(void)
{

    /* start to get temperature data */
    I2C_Start();
    i2cWrite(TEMPSENSOR_ADDRESS,0x01,0x00);
    i2cWrite(TEMPSENSOR_ADDRESS,0x01,0x81);
    i2cRepeatStartRead(TEMPSENSOR_ADDRESS,0x00, TemperatureBuffer, 2);
    temperatureBufferConverted[0] = TemperatureBuffer[0]; 
    temperatureBufferConverted[1] = temperatureConverter( TemperatureBuffer[1]);
    I2C_Stop();
}

void initializeAFE(void)
{
    //uint8 i2c_timeout = 1;
    
    I2C_Start();
    i2cWrite3(ADPD1080_ADDRESS,0x4B,0x26,0xA2);
    /* enter program mode */
    i2cWrite3(ADPD1080_ADDRESS,0x10,0x00,0x01);
    /* update prameters here */
    //i2cWrite3(ADPD1080_ADDRESS,0x14,0x05,0x49); /* setup PD and LED */
    i2cWrite3(ADPD1080_ADDRESS,0x14,0x05,0x5D);
    i2cWrite3(ADPD1080_ADDRESS,0x11,0x30,0x25);
    i2cWrite3(ADPD1080_ADDRESS,0x22,0x30,0x38);
    i2cWrite3(ADPD1080_ADDRESS,0x23,0x30,0x38);
    i2cWrite3(ADPD1080_ADDRESS,0x24,0x30,0x38);
    i2cWrite3(ADPD1080_ADDRESS,0x15,0x06,0x40);
    /* back to operation mode */
    i2cWrite3(ADPD1080_ADDRESS,0x10,0x00,0x02);

    I2C_Stop();
}



q15_t heartrateFFTBuffer[FFTNUMBER +1] = {0};
uint16 fftCounter = 0; 
uint8 heartDataBuffer[2] = {0};
uint8 readCount=0;
void readAFE(void)
{
    uint8 counter =0,dummy;
    uint8 i2c_timeout = 1,j;
    //uint8 data[2] = {0};
    I2C_Start();
    i2cWriteByte(ADPD1080_ADDRESS,0x00);
    I2C_I2CMasterSendStart(ADPD1080_ADDRESS, I2C_I2C_READ_XFER_MODE,i2c_timeout);
    //I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&counter,i2c_timeout);
    I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&counter,i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    readCount = counter;
    
    i2cWriteByte(ADPD1080_ADDRESS,0x60);
    I2C_I2CMasterSendStart(ADPD1080_ADDRESS, I2C_I2C_READ_XFER_MODE,i2c_timeout);
    I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&heartDataBuffer[0],i2c_timeout);
    I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&heartDataBuffer[0],i2c_timeout);
    I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&heartDataBuffer[1],i2c_timeout);
    I2C_I2CMasterSendStop(i2c_timeout);
    
    if(readCount!=0)
    {
        for(j=0;j<(readCount-1);j++)
        {   
            //I2C_I2CMasterReadBuf(ADPD1080_ADDRESS,heartDataBuffer,2,I2C_I2C_READ_XFER_MODE);
            I2C_I2CMasterSendStart(ADPD1080_ADDRESS, I2C_I2C_READ_XFER_MODE,i2c_timeout);
            I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&dummy,i2c_timeout);
            I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA,&dummy,i2c_timeout);
            I2C_I2CMasterSendStop(i2c_timeout);
        }
    }
    
    I2C_Stop();
    
    heartrateFFTBuffer[fftCounter] = (((uint16)heartDataBuffer[0])<<7) + (heartDataBuffer[1] >>1);
    fftCounter++;
}

void stopAFE(void)
{
    I2C_Start();
    i2cWrite3(ADPD1080_ADDRESS,0x0F,0x00,0x01);
    I2C_Stop();
}

#define BLE_BATTERY_LENGTH      (1)
#define BLE_ACCELDATA_LENGTH    (6)
#define BLE_TOUCH_LENGTH        (1)
#define BLE_TEMPERATURE_LENGTH  (2)
#define BLE_HEARTRATE_LENGTH    (2)
uint8 LED1Buf[3] = {0};
uint8 LED2Buf[3] = {0};
uint16 blePacketCounter=0;
uint8 heartRateValue = 0;
uint8 breathPerMin = 0;
void updateNotificationPacket(void)
{
    uint8 i;
    notifyBuffer[0] = batteryLevel;
    for(i=0;i<BLE_ACCELDATA_LENGTH;i++)
    {
        notifyBuffer[i + BLE_BATTERY_LENGTH] = accelgyrobuffer[i];
    }
    for(i=0;i<BLE_TOUCH_LENGTH;i++)
    {
        if(TouchResult == TRUE)
        {
            notifyBuffer[i + BLE_BATTERY_LENGTH + BLE_ACCELDATA_LENGTH] = 0xFF;//(uint8)(rawCount >>8);// TouchResult;
        }
        else
        {
            notifyBuffer[i + BLE_BATTERY_LENGTH + BLE_ACCELDATA_LENGTH] = 0;
        }
    }
    
    for(i=0;i<BLE_TEMPERATURE_LENGTH;i++)
    {
        notifyBuffer[i + BLE_BATTERY_LENGTH + BLE_ACCELDATA_LENGTH + BLE_TOUCH_LENGTH] = temperatureBufferConverted[i];
    }
    
    for(i=0;i < BLE_HEARTRATE_LENGTH;i++)
    {
        notifyBuffer[i + BLE_BATTERY_LENGTH + BLE_ACCELDATA_LENGTH + BLE_TOUCH_LENGTH + BLE_TEMPERATURE_LENGTH] = heartDataBuffer[i];
    }
    //notifyBuffer[12] = readCount; /* for Debug */
    notifyBuffer[13] = (uint8)((blePacketCounter)>>8);
    notifyBuffer[14] = (uint8)blePacketCounter;
    notifyBuffer[15] = flagWake;
    notifyBuffer[16] = heartRateValue;
    notifyBuffer[17] = breathPerMin;
    blePacketCounter++;
}


CYBLE_GATT_HANDLE_VALUE_PAIR_T		speedDataHandle;
void checkSpeedUp(void)
{
    speedFlag = speedDataHandle.value.val[0];
}

#define DATA_SIZE (256)
#define FS          (6.6666)
float arrayFFT_Freq[DATA_SIZE/2] = {0};
void generateFFTFreq(void)
{
    uint8 i;
    for(i=0;i<DATA_SIZE/2;i++)
    {
        arrayFFT_Freq[i] = FFT_BIN(i, FS, DATA_SIZE);
    }
}

void processFFTHRCaluculation()
{
    uint8 i,peak=0;
    q15_t peakValue=0;
    ZeroFFT(heartrateFFTBuffer, DATA_SIZE);
    

    for(i=32;i<DATA_SIZE/2;i++) /* i= 32 means more than 50/min heart rate is expected */
    {
        if(heartrateFFTBuffer[i] > peakValue)
        {
            peak = i;
            peakValue = heartrateFFTBuffer[i];
        }
    }
    heartRateValue = 60 * arrayFFT_Freq[peak];
}

void processFFTAccelCalculation()
{
    uint8 i,peak=0;
    q15_t peakValue=0;
    
    ZeroFFT(accelFFTBuffer, DATA_SIZE);
    for(i=8;i<DATA_SIZE/2;i++) /* i= 8 means more than 12/min breath is expected */
    //for(i=8;i<30;i++) /* i= 8 means more than 12/min breath is expected */
    {
        if(accelFFTBuffer[i] > peakValue)
        {
            peak = i;
            peakValue = accelFFTBuffer[i];
        }
    }
    breathPerMin = 60 *  arrayFFT_Freq[peak];
}

CYBLE_GAP_CONN_UPDATE_PARAM_T connectionParameters = 
{
    80,                /* Minimum connection interval - 80 x 1.25 = 100 ms */
    120,                /* Maximum connection interval - 400 x 1.25 = 500 ms */
    0,                  /* Slave latency - 0 */
    300                 /* Supervision timeout - 500 x 10 = 5000 ms */
};

uint8 BLEParametersRquestUpdatedFlag = FALSE;
void BLEParametersUpdateRquest(void)
{
    if(!BLEParametersRquestUpdatedFlag)
    {
        if(CyBle_GetState() == CYBLE_STATE_CONNECTED)
        {
            /* The parameters to the API are  - 
             * 1. Peer device's BD handle
             * 2. Pointer to 'connectionParameters' structure defined in this file
             */
            CyBle_L2capLeConnectionParamUpdateRequest(cyBle_connHandle.bdHandle, &connectionParameters);
            BLEParametersRquestUpdatedFlag = TRUE;
        }
    }
}

/* [] END OF FILE */
